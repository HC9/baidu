package com.laoxue.generation;

import com.laoxue.chrome.ChromiumDriver;
import com.laoxue.chrome.DriverUtil;
import com.laoxue.util.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Set;

import static com.laoxue.config.CommonValue.*;
import static com.laoxue.config.MainConfig.*;
import static com.laoxue.generation.GenerationController.ACCOUNT_TITLE_MAPPING;
import static com.laoxue.util.Sleep.sleep4Second;

/**
 * 核心下载类
 *
 * @author 老薛 vx:kengwanglaoxue
 */
public class GenerationDownload {

	static int articleNum = 0;

	/*
	 * 账号下载，在账号下载的过程中
	 * accountMapping： account1.csv--> 存储一个里面的所有的账号
	 * titlesMapping ： titles1.csv --> 存储一个里面的所有的标题信息
	 * */
	public static void download (Map<String, Map<String, Set<Cookie>>> accountMapping, Map<String, Map<String, List<String>>> titlesMapping) {
		// 确定循环的次数 账号文件夹个数来确定
		for (String titleFile : ACCOUNT_TITLE_MAPPING.keySet()) {
			// 声明变量 存储账号要生成的文件个数
			int fileTitleCount = CREATE_NUM;
			Log.printSuccess("准备账号", "读取账号文件[" + titleFile + "]，读取标题文件[" + ACCOUNT_TITLE_MAPPING.get(titleFile) + "]");

			//获取到当前titleFile文件夹下所有的账号数据信息
			Map<String, Set<Cookie>> accountMap = accountMapping.get(titleFile);
			Log.printSuccess("读取账号数据", "累计读取到账号数据个数" + accountMap.keySet().size() + "个");
			Map<String, List<String>> titleMap = titlesMapping.get(ACCOUNT_TITLE_MAPPING.get(titleFile));
			Log.printSuccess("读取标题数据", "累计读取到标题数据个数" + titleMap.values().stream().mapToInt(List::size).sum() + "个");


			try {
				generatorArticle(accountMap, titleMap);
				Log.printSuccess("生成完毕", "累计生成文章个数" + articleNum + "篇");
				articleNum = 0;

			} catch (Exception e) {
				// 根据抛出的异常来决定接下来的问题
			}

		}
	}

	// 生成文章前期准备工作
	private static void generatorArticle (Map<String, Set<Cookie>> accountMap, Map<String, List<String>> titleMap) {
		int n = 1;
		switchAccount:
		for (String account_key : accountMap.keySet()) {
			ChromiumDriver chromeDriver = null;
			try {
				chromeDriver = DriverUtil.getChromiumDriver();
				chromeDriver.get(GENERATION_HREF);
				Log.printSuccess("登录网站", "成功");
				// 等待刷新网页
				sleep4Second(5);
				chromeDriver.manage().deleteAllCookies();
				for (Cookie cookie : accountMap.get(account_key)) {
					chromeDriver.manage().addCookie(cookie);
				}
				Log.printSuccess("读取账号", account_key + "成功");
				chromeDriver.navigate().refresh();
				// 等待刷新网页
				sleep4Second(5);
				WebDriverWait wait = new WebDriverWait(chromeDriver, 5);
				wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"app\"]/div[1]/section/section/aside/div/div[1]/div[3]/div[3]/span")));

				sleep4Second(2);
				WebElement laboratory = chromeDriver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/section/section/aside/div/div[1]/div[3]/div[3]/span"));
				laboratory.click();

				//点击文章生成器
				sleep4Second(2);
				WebElement generated = chromeDriver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/section/section/section/main/div[2]/div/div/div/div[1]/div/div/div[1]"));
				generated.click();

				sleep4Second(2);
				WebElement articleLengthSelection = chromeDriver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/section/section/section/main/div/div/div[1]/div/div[2]/div[2]/div/div/span/span/i"));
				articleLengthSelection.click();

				sleep4Second(2);

				//判定用户生成的文章长度
				WebElement shortFilm = null;
				Log.printSuccess("长度", SPACE);
				switch (SPACE) {
					case "短":
						shortFilm = chromeDriver.findElement(By.xpath("/html/body/div[3]/div[1]/div[1]/ul/li[1]/span"));
						break;
					case "中":
						shortFilm = chromeDriver.findElement(By.xpath("/html/body/div[3]/div[1]/div[1]/ul/li[2]/span"));
						break;
					case "长":
						shortFilm = chromeDriver.findElement(By.xpath("/html/body/div[3]/div[1]/div[1]/ul/li[3]/span"));
						break;
					case "超长":
						shortFilm = chromeDriver.findElement(By.xpath("/html/body/div[3]/div[1]/div[1]/ul/li[4]/span"));
						break;
					default:
						throw new IllegalArgumentException("SPACE选择生成文章长度有问题");
				}
				shortFilm.click();


				Log.printSuccess("生成", SPACE);
				sleep4Second(5);


				if (titleMap.isEmpty()) {
					Log.printSuccess("读取完毕", "文章已经读取结束");
					chromeDriver.quit();
					return;
				}

				// 存储下载文章时出现的问题
				int downloadCount = 0;

				Set<String> title_keys = titleMap.keySet();
				int m = 0;
				for (String title_key : title_keys) {
					List<String> titles = titleMap.get(title_key);
					for (ListIterator<String> titleIterator = titles.listIterator(); titleIterator.hasNext(); ) {
						String title = titleIterator.next();
						sleep4Second(2);
						try {
							Log.printSuccess("准备生成文章", title);
							// 输入值
							WebElement keyword = chromeDriver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/section/section/section/main/div/div/div[1]/div/div[2]/div[1]/input"));
							keyword.clear();
							keyword.sendKeys(title.replace(SEGMENTATION, COMMA));
							Log.printSuccess("生成文章", title);
							sleep4Second(1);


							//点击生成
							WebElement clickGenerated = chromeDriver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/section/section/section/main/div/div/div[1]/div/div[2]/div[3]"));
							clickGenerated.click();
							sleep4Second(WAITTIME);

							//点击下载
							WebElement download = chromeDriver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/section/section/section/main/div/div/div[1]/div/div[3]/div/div[1]/div/button"));
							download.click();
							sleep4Second(1);


							// 移除当前文章
							Log.printSuccess("生成文章", title);
							titleIterator.remove();
							Log.printSuccess("移除文章", title);
							if (titles.isEmpty()) {
								titleMap.remove(title_key);
							}
							articleNum++;
						} catch (Exception e) {
							downloadCount++;
							// 如果单个账号生成文章异常3次 则切换账号
							if (downloadCount >= 3) {
								downloadCount = 0;
								// 出现异常就将这个文件删除
								Log.printFail("文章下载失败", account_key + "账号出现生成文章3次异常，切换账号");
								Log.printFail("文章删除", "将" + title + "文件删除，继续读取");
								// 移除当前文章
								titleIterator.remove();
								if (titles.isEmpty()) {
									titleMap.remove(title_key);
								}
								chromeDriver.quit();
								continue switchAccount;
							}
							// 出现异常就将这个文件删除
							Log.printException("文章下载", new IllegalArgumentException("文件下载" + title + "，生成过程中有问题"));
							Log.printSuccess("文章删除", "将" + title + "文件删除，继续读取");
							// 移除当前文章
							titleIterator.remove();
							if (titles.isEmpty()) {
								titleMap.remove(title_key);
							}
							continue;
						}
					}

				}
			} catch (Exception e) {
				Log.printException("账号登录生成文章过程", e);
			} finally {
				assert chromeDriver != null;
				chromeDriver.quit();
			}

		}
	}
}
