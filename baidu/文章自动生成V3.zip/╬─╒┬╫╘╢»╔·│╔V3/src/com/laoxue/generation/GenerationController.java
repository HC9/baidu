package com.laoxue.generation;

import com.laoxue.exception.FileCountException;
import com.laoxue.exception.ReadAccountFileException;
import com.laoxue.util.FileUtil;
import com.laoxue.util.Log;
import org.apache.commons.lang3.SerializationUtils;
import org.openqa.selenium.Cookie;

import java.io.File;
import java.io.IOException;
import java.util.*;

import static com.laoxue.config.MainConfig.*;
import static com.laoxue.util.FileUtil.copyFileToDest;
/**
 *  下载控制
 *  @author 老薛 vx:kengwanglaoxue
 */
public class GenerationController {
    public static Map<String,String> ACCOUNT_TITLE_MAPPING = new HashMap<>();

    public static void generationArticle() {
        try{
            // 读取所有的账号数据
            Log.printSuccess("读取账号信息","开始");
            Map<String, Map<String, Set<Cookie>>> accountMapping = readAccounts();
            Log.printSuccess("读取账号信息","结束\n\n");


            // 读取所有的标题数据
            Log.printSuccess("读取标题信息","开始\n");
            Map<String,Map<String, List<String>>> titlesMapping = readTitles();
            Log.printSuccess("读取标题信息","结束\n\n");


            // 存储一份读取到的标题数据
            Map<String,Map<String, List<String>>> copy = SerializationUtils.clone((HashMap) titlesMapping);


            checkBounds(accountMapping,titlesMapping);

            // 建议账号数据和标题数据的映射
            buildMapping(accountMapping,titlesMapping);

            // 准备下载
            Log.printSuccess("下载PDF文件","开始");
            GenerationDownload.download(accountMapping,titlesMapping);
            Log.printSuccess("下载PDF文件","结束\n\n");


            //整理文件 TODO 这里可以优化 在下载的时候指定下载地址 这一步就可以省略
            Log.printSuccess("整理下载路径","开始\n");
            copyFileToDest(copy);
            Log.printSuccess("整理下载路径","结束\n\n");

        }catch (FileCountException | ReadAccountFileException e) {
            Log.printException("读取标题或者账号数据出现异常,退出程序", e);
        } catch (RuntimeException e){
            Log.printException("执行过程中出现异常",e);
        } catch (IOException e) {
            Log.printException("pdf文件整理过程中出现异常",e);
        }
    }


    /*建立账号文件和标题文件的映射关系*/
    private static void buildMapping(Map<String, Map<String, Set<Cookie>>> accountMapping, Map<String, Map<String, List<String>>> titlesMapping) {
        Set<String> accountFiles = accountMapping.keySet();
        Set<String> titleFiles = titlesMapping.keySet();

        for (Iterator<String> accountIt = accountFiles.iterator(),
             titleIt=titleFiles.iterator();accountIt.hasNext()&&titleIt.hasNext();){
            ACCOUNT_TITLE_MAPPING.put(accountIt.next(),titleIt.next());
        }

    }


    // 检查文件的个数
    private static void checkBounds(Map<String, Map<String, Set<Cookie>>> accountMapping, Map<String, Map<String, List<String>>> titlesMapping) {
        if (accountMapping==null||accountMapping.size()==0||titlesMapping==null||titlesMapping.size()==0)
            throw new FileCountException("账号文件或标题文件中暂无数据");
        if (accountMapping.size()!=titlesMapping.size())
            throw new FileCountException("账号文件和标题文件个数不统一");
    }


    /**
     * 读取标题数据信息
     * 读取生成的文件夹下的优质标题信息
     */
    public static Map<String, Map<String, List<String>>> readTitles() {
        Map<String, Map<String, List<String>>> titlesMapping = new HashMap<>();

        // 根据配置选择优先读取那个标题文件
        for (String titleFile:PRIORITY_CHOOSE?BUILD_OK_TITLE_FILE:BUILD_POOR_TITLE_FILE){
            titlesMapping.put(titleFile,FileUtil.parseFile4Map(titleFile));
        }

        return  titlesMapping;
    }

    /**
     * 读取账号数据信息
     * account1->account1.csv account2.csv
     */
    private static Map<String, Map<String, Set<Cookie>>> readAccounts() {
        Map<String, Map<String, Set<Cookie>>> accountMapping = new HashMap<>();
        File accountsFolder = new File(ACCOUNT_CSV_FILE); // 读取到一层
        // 获取它下面有多少个文件夹
        File[] accountFolder = accountsFolder.listFiles();
        if (accountFolder==null||accountFolder.length==0)
            throw new FileCountException("账号文件夹下没有账号数据");
        //必须要保证账户文件夹下有下一级文件夹，然后才是账户csv文件
        Log.printSuccess("读取账号","一共读取到账号文件夹"+accountFolder.length+"个");
        for (File account:accountFolder){
            //判定当前file是否是文件夹
            if (!account.isDirectory())
                throw new FileCountException("账号文件夹下没有文件夹，必须要保证账户文件夹下有下一级文件夹，" +
                        "然后才是账户csv文件 类似account\\account1\\account1.csv");
            Log.printSuccess("读取账号","准备读取所有的账号文件夹下的账号数据");
            File[] accounts = account.listFiles();
            if (accounts==null||accounts.length==0)
                throw new FileCountException("账号文件夹下没有账号数据");
            for (File ac:accounts){
                if (!ac.isFile())
                    throw new FileCountException("账号文件夹下存在文件夹");
            }
            // 将accounts这个数组文件中的所有文解析成为一个map集合
            Log.printSuccess("读取账号","读取"+account.getAbsolutePath()+"文件夹下的数据 [开始]");
            Map<String, Set<Cookie>> acc = FileUtil.parseFolder4Map(accounts);
            Log.printSuccess("读取账号","读取数据"+acc.keySet().size()+"个账号信息");
            Log.printSuccess("读取账号","读取"+account.getAbsolutePath()+"文件夹下的数据 [结束]");
            accountMapping.put(account.getAbsolutePath(),acc);
        }
        return accountMapping;
    }


}
