package com.laoxue.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import static com.laoxue.config.MainConfig.GEN_LOG_PATH;
import static java.lang.System.out;

public class Log {
	static {
		try {
			File file = new File(GEN_LOG_PATH);
			if (!file.exists()) {
				file.createNewFile();
			}
			System.setOut(new PrintStream(
					new FileOutputStream(file, true), true, "utf-8"));
		} catch (IOException e) {
			printException("写出日志异常", e);
		}
	}

	public static void printFail (String operator, String msg) {
		out.println(getDate() + "【" + operator + "】 失败 ：\t" + msg);
	}

	public static void printSuccess (String operator, String msg) {
		out.println(getDate() + "【" + operator + "】  ：\t" + msg);
	}

	public static void printException (String operator, Exception e) {
		out.println(getDate() + "【" + operator + "】 出现异常 ：\n" + ExceptionUtil.getExceptionMessage(e));
	}

	private static String getDate () {
		return new SimpleDateFormat("yyyy年MM月dd日 hh:mm:ss").format(new Date());
	}

}
