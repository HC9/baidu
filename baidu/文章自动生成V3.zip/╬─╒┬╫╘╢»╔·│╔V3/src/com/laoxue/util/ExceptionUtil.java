package com.laoxue.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

/**
 * <p>项目名称: generatorAracial </p>
 * <p>包名称: PACKAGE_NAME </p>
 * <p>描述:  </p>
 * <p>  </p>
 * <p>创建时间: 2022/12/12 16 </p>
 *
 * @author coco
 * @version v1.0
 */
public class ExceptionUtil {

	/**
	 * 获取异常信息
	 *
	 * @param e 异常
	 * @return 返回异常信息
	 */
	public static String getExceptionMessage (Exception e) {

		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw, true);
		e.printStackTrace(pw);
		try {
			sw.close();
			pw.close();
		} catch (IOException ex) {
			throw new RuntimeException(ex);
		}
		// 关闭IO流
		return sw.toString();
	}
}

