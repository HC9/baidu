package com.laoxue.util;

import java.util.concurrent.TimeUnit;

/*休眠工具类*/
public class Sleep {
    public static void sleep4Second(long second){
        try {
            TimeUnit.SECONDS.sleep(second);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void sleep4Mills(long mills){
        try {
            TimeUnit.MILLISECONDS.sleep(mills);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


}
