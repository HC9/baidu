package com.laoxue.util;

import com.laoxue.exception.FileCountException;
import com.laoxue.exception.ReadAccountFileException;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Cookie;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import static com.laoxue.config.CommonValue.*;
import static com.laoxue.config.MainConfig.*;

public class FileUtil {

	/**
	 * 读取一个文件数组 将这个文件数组中的所有的文件数据读取出来 放到map集合中
	 *
	 * @param accountFiles
	 * @return
	 */
	public static Map<String, Set<Cookie>> parseFolder4Map (File[] accountFiles) {
		Map<String, Set<Cookie>> accounts = new HashMap<>();
		// 检查账号文件
		checkAccountFile(accountFiles);
		// 读取每一个文件的账号数据
		for (int i = 0; i < accountFiles.length; i++) {
			List<Map<String, Set<Cookie>>> accountsList = readSingleCsv(accountFiles[i]);
			wrapperAccountMap(accounts, accountsList);
		}
		return accounts;
	}

	/*将List中的账号数据包装到Map集合里面*/
	private static void wrapperAccountMap (Map<String, Set<Cookie>> accounts, List<Map<String, Set<Cookie>>> accountsList) {
		for (Map<String, Set<Cookie>> mps : accountsList) {
			Set<String> phones = mps.keySet();
			for (String phone : phones) {
				accounts.put(phone, mps.get(phone));
			}
		}
	}

	private static void checkAccountFile (File[] accounts) {
		if (accounts.length == 0)
			throw new FileCountException("文件路径下没有账号文件");
	}


	/*读取单篇csv账号文件*/
	private static List<Map<String, Set<Cookie>>> readSingleCsv (File accountFile) {
		List<Map<String, Set<Cookie>>> account = null;
		try (ObjectInputStream fip = new ObjectInputStream(Files.newInputStream(accountFile.toPath()))) {
			account = (List<Map<String, Set<Cookie>>>) fip.readObject();
			//List<Map<String, Set<Cookie>>>
			if (account.size() < 1) {
				Log.printFail("读取账号文件", "文件格式有误，无法读取");
				throw new ReadAccountFileException("读取文件账号异常");
			}
		} catch (IOException | ClassNotFoundException e) {
			Log.printException("读取账号", new ReadAccountFileException("读取文件账号异常"));
		}
		return account;
	}


	public static List<File> getFolderNameFilter (String path, String filter) {
		List<File> names = new ArrayList<>();
		File file = new File(path);
		if (!file.exists()) {
			System.out.println("文件路径不存在，请查证" + path);
			throw new RuntimeException("文件路径不存在，请查证" + path);
		}
		File[] files = file.listFiles();
		for (File f : files) {
			if (f.getName().contains(filter)) {
				names.add(f);
			}
		}
		return names;
	}

	/*读取标题文件 将文件中的类目和标题形成映射关系存入map中*/
	public static Map<String, List<String>> parseFile4Map (String filePath) {
		File titleFile = new File(filePath);
		Log.printSuccess("读取标题", "读取" + titleFile.getAbsolutePath() + "文件中的标题数据 [开始]");
		// 读取到指定文件夹下的标题
		Map<String, List<String>> retResult = readFileTitle4Filter(titleFile);

		Log.printSuccess("读取标题", "读取" + titleFile.getAbsolutePath() + "文件中的标题数据 [结束]");

		// 读取需要生成的标题信息
		Log.printSuccess("读取标题", "读取本次生成文件中的标题数据 [开始]");
		Map<String, List<String>> needTitle = getNeedTitle(retResult);
		Log.printSuccess("读取标题", "读取本次生成文件中的标题数据 [结束]\n");

		return needTitle;
	}

	private static Map<String, List<String>> readFileTitle4Filter (File titleFile) {
		Map<String, List<String>> retResult = new LinkedHashMap<>();
		try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(
				new FileInputStream(titleFile), "utf-8"))) {
			String line;
			String[] items;
			ArrayList<String> titles = null;
			while ((line = bufferedReader.readLine()) != null) {
				items = line.split(",");
				if ("分类".equals(items[0])) continue;
				//TODO 防止标题读取进来之后不完整 所以CSV文件增加了@ 读取的时候修改回来 但是在整理的时候可能会有问题 找不到文件
				//TODO 目前的解决办法是整理的时候随机读取1-6个字符信息 如果对上就直接移动[应该没啥问题]
				String title = items[1];

				if (!retResult.containsKey(items[0])) {
					titles = new ArrayList<>();
				}
				titles.add(title);
				retResult.put(items[0], titles);
			}
		} catch (IOException e) {
			Log.printException("读取标题", new ReadAccountFileException("读取标题文件出现异常"));
		}
		Log.printSuccess("读取标题", "读取" + titleFile.getName() + "文件中的标题数据，合集读取到" +
				"分类信息：" + retResult.keySet().size() + "个，读取到标题数据：" + retResult.values().stream().mapToInt(List::size).sum() + "条");
		return retResult;
	}

	private static Map<String, List<String>> writeCsv (Map<String, List<String>> mps,
	                                                   Map<String, List<String>> needTitle, String filePath) {

		Log.printSuccess("总计文档数据", mps.values().stream().mapToInt(List::size).sum() + "个");
		Map<String, List<String>> writeMap = getDifference(mps, needTitle);
		Log.printSuccess("剩余文档数据", writeMap.values().stream().mapToInt(List::size).sum() + "个");

		File destFile = new File(filePath);
		if (destFile.exists())
			destFile.delete();
		File file = new File(filePath);
		if (!file.exists())
			try {
				file.createNewFile();
			} catch (IOException e) {
				Log.printException("文件创建失自己手动创建ok.csv和poor.csv吧", e);
			}
		writeCsv(writeMap, file.getParentFile().getPath(), file.getName());
		return needTitle;
	}

	private static Map<String, List<String>> getDifference (Map<String, List<String>> mps,
	                                                        Map<String, List<String>> needTitle) {
		Map<String, List<String>> getTitles = new HashMap<>();
		for (String keys : mps.keySet()) {
			List<String> ls = new ArrayList<>();
			if (!needTitle.containsKey(CREATE_FOLDER.get(keys))) {
				List<String> strings = mps.get(keys);
				for (String title : strings) {
					ls.add(title);
				}
			} else {
				List<String> titles1 = mps.get(keys);
				List<String> titles2 = needTitle.get(CREATE_FOLDER.get(keys));
				for (String title : titles1) {
					if (!titles2.contains(title/*.replace(SEGMENTATION,COMMA)*/)) {
						ls.add(title);
					}
				}
			}
			getTitles.put(keys, ls);
		}
		return getTitles;
	}


	/*读取需要的标题数据*/
	private static Map<String, List<String>> getNeedTitle (Map<String, List<String>> titles) {
		Map<String, List<String>> needs = new LinkedHashMap<>();
		int need_count = CREATE_NUM;
		Log.printSuccess("读取标题", "本次生成pdf文章合计" + need_count + "篇");
		List<String> filterCategory = getFilterCategory();
		int copy_count = 0;
		for (String category : filterCategory) {
			if (titles.containsKey(category)) {
				Log.printSuccess("读取优先标题", "生成" + category + "分类信息");
				List<String> ls = new ArrayList<>();
				List<String> ts = titles.get(category);
				Log.printSuccess(category + "分类", "合计" + ts.size() + "篇标题文章");
				for (String str : ts) {
					Log.printSuccess("读取标题", str);
					if (copy_count == need_count) {
						needs.put(category, ls);
						return needs;
					}
					ls.add(str);
					copy_count++;
				}
				needs.put(category, ls);
			}
		}
		// 复制
		for (String title : titles.keySet()) {
			List<String> strings = titles.get(title);
			List<String> ls = new ArrayList<>();
			Log.printSuccess("读取一般标题", "生成" + title + "分类信息");
			Log.printSuccess(title + "分类", "生成" + strings.size() + "篇标题文章");
			for (String str : strings) {
				if (copy_count == need_count) {
					needs.put(title, ls);
					return needs;
				}
				ls.add(str);
				copy_count++;
			}
			needs.put(title, ls);
		}
		return needs;
	}


	public static void copyFileToDest (Map<String, Map<String, List<String>>> destMap) throws IOException {

		Log.printSuccess("删除CSV文件", "删除开始");
		// 删除掉原本csv文件中的内容
		removeCsv(destMap);
		Log.printSuccess("删除CSV文件", "删除结束\n");

		Log.printSuccess("准备整理", "PDF文件");
		Set<String> files = destMap.keySet();
		for (String f : files) {
			File destFile = new File(PDF_FILEPATH + (new File(f).getParentFile().getParentFile().getName()) + "\\");
			Log.printSuccess("PDF移动位置", destFile.getAbsolutePath());
			//TODO:注意 每天跑完之后一定记得删了这个文件夹 否则就找不到了
			//TODO:解决办法 可以新建一个文件夹 通过时间记录文件夹即可 懒的写了
			if (!destFile.exists())
				destFile.mkdirs();

			Map<String, List<String>> titleMaps = destMap.get(f);
			Set<String> folders = titleMaps.keySet();
			for (String folder : folders) {
				List<String> titles = titleMaps.get(folder);
				for (String title : titles) {
					title = title.replace(SEGMENTATION, COMMA);
					File file = new File(DOWNLOAD_PATH + title + ".pdf");
					Log.printSuccess("PDF下载位置", file.getAbsolutePath());
					if (file.exists()) {
						File dest = new File(destFile + "\\" + folder + "\\");
						if (!dest.exists())
							dest.mkdirs();

						FileUtils.moveFile(new File(DOWNLOAD_PATH + title + ".pdf"),
								new File(destFile + "\\" + folder + "\\" + title + ".pdf"));
						Log.printSuccess("PDF移动", "成功\n");
					}

				}
			}

		}
	}

	private static void removeCsv (Map<String, Map<String, List<String>>> destMap) {
		Log.printSuccess("准备删除", "读取创作活动的标题信息");
		File titlesFolder = new File(TITLE_CSV_FILE);
		File[] titleFiles = titlesFolder.listFiles();
		int index = 0;
		Set<String> files = destMap.keySet();
		for (String file : files) {
			Map<String, List<String>> contents = destMap.get(file);
			for (int i = 0; i < titleFiles.length; i++) {
				File file1 = new File(file);
				String fileName = titleFiles[i].getName();
				if (fileName.split("\\.")[0].equals(file1.getParentFile().getParentFile().getName())) {
					index = i;
					break;
				}
			}

			assert titleFiles != null;
			removeCsv(titleFiles[index], contents);
		}
	}

	private static void removeCsv (File titleFile, Map<String, List<String>> contents) {
		Log.printSuccess("删除文件", "删除" + titleFile.getName() + "文件中的标题信息");

		// 先读取 如果是包含在map集合中的则跳过
		Map<String, List<String>> stringListMap = readFileTitle(titleFile);

		// 将这个集合写出
		Map<String, List<String>> difference = getDifference(stringListMap, contents);
		Log.printSuccess("写出文件", "读取" + titleFile.getAbsolutePath() + "文件中的标题数据，合集读取到" +
				"分类信息：" + difference.keySet().size() + "个，读取到标题数据：" + difference.values().stream().mapToInt(List::size).sum() + "条");


		writeCsv(difference, titleFile.getParentFile().getAbsolutePath(), titleFile.getName());

		Log.printSuccess("写出CSV文件", "写出成功");
	}


	/*读取所有的标题数据*/
	private static Map<String, List<String>> readFileTitle (File titleFile) {
		Map<String, List<String>> retResult = new LinkedHashMap<>();
		try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(
				Files.newInputStream(titleFile.toPath()), StandardCharsets.UTF_8))) {
			String line;
			String[] items;
			ArrayList<String> titles = null;
			while ((line = bufferedReader.readLine()) != null) {
				try {
					items = line.split(",");
					if ("分类".equals(items[0])) continue;
					String title = items.length > 2 ? items[4] : items[1];
					// if (title.startsWith("\"") && title.endsWith("\"") && title.contains(",")){
					//     title = title.substring(1,title.length() -1);
					// }
					if (!retResult.containsKey(items[0])) {
						titles = new ArrayList<>();
					}
					titles.add(title);
					retResult.put(items[0], titles);
				} catch (ArrayIndexOutOfBoundsException e) {

				}
			}
		} catch (IOException e) {
			Log.printException("读取标题", new RuntimeException("读取标题文件出现异常"));
		}
		Log.printSuccess("读取标题", "读取" + titleFile.getAbsolutePath() + "文件中的标题数据，合集读取到" +
				"分类信息：" + retResult.keySet().size() + "个，读取到标题数据：" + retResult.values().stream().mapToInt(List::size).sum() + "条");
		return retResult;
	}


	/*读取配置的优先分类信息*/
	private static List<String> getFilterCategory () {
		String[] category = CATEGORY.split(",");
		List<String> ls = new ArrayList<>();
		for (String cate : category) {
			ls.add(cate);
		}
		Log.printSuccess("读取标题", "本次生成优先分类分别是[" + ls + "]");
		return ls;
	}


	/* 整理标题文件 */
	public static void fixUpTitle () {
		Log.printSuccess("整理标题文档", "准备标题数据分类【开始】");
		File titlesFolder = new File(TITLE_CSV_FILE);
		File[] titleFiles = titlesFolder.listFiles();
		if (titleFiles == null || titleFiles.length == 0)
			throw new FileCountException("标题文件夹下没有标题数据");
		for (File title : titleFiles) {
			if (!title.isFile())
				throw new FileCountException("标题文件夹下有其他非标题文件信息" + title.getAbsolutePath());
		}

		Log.printSuccess("整理标题文档", "一共读取到标题文件" + titleFiles.length + "个");

		// 循环读取标题
		for (File titleFile : titleFiles) {
			readFile4Csv(titleFile, titleFile.getName().split("\\.")[0]);
		}

		Log.printSuccess("整理标题文档", "准备标题数据分类【结束】\n\n");
	}

	/*读取爬取下来的csv文件*/
	private static void readFile4Csv (File filePath, String fileName) {
		Map<String, List<String>> TITLE_MAPPING = new HashMap<>();
		try (BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(
				Files.newInputStream(filePath.toPath()), StandardCharsets.UTF_8))) {
			String line;
			String[] items;
			ArrayList<String> titles = null;
			b:
			while ((line = bufferedReader.readLine()) != null) {
				items = line.split(",");
				// if (items.length == 5) {
				//TODO:将读取到的文件中的不能上传的过滤掉
				if ("分类".equals(items[0]) || (items.length > 2 && ("false".equals(items[3]) || items[4].contains("/") || items[4].contains(".")))) continue;
				if (items.length > 2) {
					for (String s : IGNORE_TEXT) {
						if (items[4].contains(s)) {
							continue b;
						}
					}
				}
				String title = "";
				title = items.length > 2 ? items[4] : items[1];
				if (!TITLE_MAPPING.containsKey(items[0]))
					titles = new ArrayList<>();
				titles.add(title);
				TITLE_MAPPING.put(items[0], titles);
				// } else {
				// 	Log.printSuccess("整理标题", "标题字段不等于4，请检查是否整理过");
				// 	break;
				// }
			}
			Log.printSuccess("整理标题文档", "读取总计类目：" + TITLE_MAPPING.size()
					+ "，总计条目：" + TITLE_MAPPING.values().stream().mapToInt(List::size).sum());
			filterTitle(TITLE_MAPPING, fileName);
		} catch (IOException e) {
			Log.printException("读取文件", e);
		}
	}

	/*过滤标题信息*/
	private static void filterTitle (Map<String, List<String>> TITLE_MAPPING, String fileName) {
		Map<String, List<String>> TITLE_OK = new LinkedHashMap<>();
		Map<String, List<String>> TITLE_POOR = new LinkedHashMap<>();
		Set<String> classifys = TITLE_MAPPING.keySet();
		List<String> ok_lists = null;
		List<String> poor_lists = null;
		for (String classify : classifys) {
			List<String> titles = TITLE_MAPPING.get(classify);
			if (!TITLE_OK.containsKey(CREATE_FOLDER.get(classify)))
				ok_lists = new ArrayList<>();
			if (!TITLE_POOR.containsKey(CREATE_FOLDER.get(classify)))
				poor_lists = new ArrayList<>();
			for (String title : titles) {
				boolean is_distinguish = false;
				for (String keywords : FILTER_KEYWORD) {
					if (title.contains(keywords)) {
						if (title.length() >= 5 && !title.substring(0, 5).contains(DOT)) {
							assert ok_lists != null;
							ok_lists.add(title);
							is_distinguish = true;
							break;
						}

					}
				}
				if (!is_distinguish) {
					assert poor_lists != null;
					poor_lists.add(title);
				}
			}
			TITLE_OK.put(CREATE_FOLDER.get(classify), ok_lists);
			TITLE_POOR.put(CREATE_FOLDER.get(classify), poor_lists);
		}

		Log.printSuccess("文档标题分类", "读取墨斗鱼标题总计【优质】类目：" + TITLE_OK.keySet().size() + ",总计条目：" + TITLE_OK.values().stream().mapToInt(List::size).sum());
		Log.printSuccess("文档标题分类", "读取墨斗鱼标题总计【一般】类目：" + TITLE_POOR.keySet().size() + ",总计条目：" + TITLE_POOR.values().stream().mapToInt(List::size).sum());

		//将生成的文档路径写出到集合中
		BUILD_OK_TITLE_FILE.add(CLASSIFICATION_FOLDER + fileName.split(",")[0] + OK_TITLE_FILE + "OK.csv");
		BUILD_POOR_TITLE_FILE.add(CLASSIFICATION_FOLDER + fileName.split(",")[0] + POOR_TITLE_FILE + "POOR.csv");
		// 写出这两个文档信息
		writeCsv(TITLE_OK, CLASSIFICATION_FOLDER + fileName.split(",")[0] + OK_TITLE_FILE, "OK.csv");
		writeCsv(TITLE_POOR, CLASSIFICATION_FOLDER + fileName.split(",")[0] + POOR_TITLE_FILE, "POOR.csv");

	}

	/* 写出csv文件 */
	private static void writeCsv (Map<String, List<String>> titlesCys, String path, String fileName) {

		File destFile = new File(path);
		Log.printSuccess("备份CSV文件", "开始备份");
		if (!destFile.exists()) {
			destFile.mkdirs();
		}

		File file = new File(path + "\\" + fileName);
		if (file.exists()) {
			Log.printSuccess("备份文件", "备份" + file.getAbsolutePath());
			Log.printSuccess("备份文件", "备份到" + BACK_FOLDER);
			backupFile(BACK_FOLDER, file);
			file.delete();
		} else
			try {
				file.createNewFile();
			} catch (IOException e) {
				Log.printException("文件创建失自己手动创建ok.csv和poor.csv吧", e);
			}
		try (BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(
				Files.newOutputStream(file.toPath()), StandardCharsets.UTF_8))) {
			bufferedWriter.write("分类,名称");
			bufferedWriter.newLine();
			Set<String> classifys = titlesCys.keySet();
			for (String classify : classifys) {
				List<String> titles = titlesCys.get(classify);
				for (String title : titles) {
					bufferedWriter.write(classify + "," + title);
					bufferedWriter.newLine();
				}
			}
		} catch (IOException e) {
			Log.printException("写出标题文件出现异常", e);
		}
	}

	private static void backupFile (String backFolder, File oldFile) {
		String s = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd-HH-mm-ss-SSS"));
		File file = new File(backFolder + s + oldFile.getName());
		Log.printSuccess("备份文件", "即将备份" + file.getAbsolutePath());
		if (file.exists()) {
			Log.printSuccess("备份文件", "文件存在，删除");
			file.delete();
		}
		// try {
		// 	Log.printSuccess("备份文件", "创建文件" + file.getAbsolutePath());
		// 	file.createNewFile();
		// } catch (IOException e) {
		// 	Log.printFail("备份文件", "备份文件创建失败");
		// 	throw new RuntimeException(e);
		// }
		try {
			Log.printSuccess("备份文件", "开始拷贝");
			Files.copy(oldFile.toPath(), file.toPath());
			Log.printSuccess("备份文件", "拷贝完成");
		} catch (IOException e) {
			Log.printFail("备份文件", "拷贝出错");
			throw new RuntimeException(e);
		}
	}


}
