package com.laoxue.exception;

/**
 * 文件异常
 */
public class FileCountException extends RuntimeException{
    public FileCountException(){super();}
    public FileCountException(String msg){super(msg);}
}