package com.laoxue.exception;

/**
 * 读取账号文件异常
 */
public class ReadAccountFileException extends RuntimeException{
    public ReadAccountFileException(){super();}
    public ReadAccountFileException(String msg){super(msg);}
}