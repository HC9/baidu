package com.laoxue.config;

import com.laoxue.util.Log;
import com.laoxue.util.StringUtil;
import org.apache.commons.lang3.StringUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

/**
 * 主配置信息
 *
 * @author 老薛 vx:kengwanglaoxue
 */
public class MainConfig {

	public static String ACCOUNT_CSV_FILE;// 账号配置路径 "C:\\generatedArticle\\account\\"
	public static String TITLE_CSV_FILE;//标题文件配置路径 "C:\\generatedArticle\\title\\"
	public static String CHROME_DRIVER_PATH; //chrome 驱动配置路径
	public static String GEN_LOG_PATH; //日志文件配置路径
	public static String DOCUMENT_LOCATION; //整理后的文件配置路径
	public static String SPACE; //生成文章的篇幅 短、中、长
	public static int CREATE_NUM; //生成文件的数量 每个账号的生产数量
	public static String CATEGORY;// 优先读取类目信息

	public static String BACK_FOLDER;//备份目录
	public static int WAITTIME;// 等待读取的时间 短片15S 中篇 30S 长篇更久
	public static String CLASSIFICATION_FOLDER;// 标题分类文件夹 "C:\\generatedArticle\\classification\\"
	public static List<String> BUILD_OK_TITLE_FILE = new ArrayList<>(); // 生成的优质标题文档路径列表
	public static List<String> BUILD_POOR_TITLE_FILE = new ArrayList<>();// 生成的一般标题文档路径列表
	public static List<String> IGNORE_TEXT = new ArrayList<>();
	public static boolean PRIORITY_CHOOSE; // true 优先读取优质文档路径，false 优先读取一般文档路径
	public static boolean IS_FIX_UP; //是否需要整理
	public static String DOWNLOAD_PATH;//下载的路径
	public static String PDF_FILEPATH; //PDF存放的路径

	public static String EXE_FILE_PATH; //脚本文件存放的目录

	static {
		EXE_FILE_PATH = System.getProperty("user.dir");
		Properties properties = new Properties();

		try (InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(EXE_FILE_PATH + "\\conf.properties"), StandardCharsets.UTF_8); BufferedReader bufferedReader = new BufferedReader(inputStreamReader);) {
			properties.load(bufferedReader);
			ACCOUNT_CSV_FILE = EXE_FILE_PATH + properties.getProperty("ACCOUNT_CSV_FILE");
			TITLE_CSV_FILE = EXE_FILE_PATH + properties.getProperty("TITLE_CSV_FILE");
			CHROME_DRIVER_PATH = EXE_FILE_PATH + properties.getProperty("CHROME_DRIVER_PATH");
			GEN_LOG_PATH = EXE_FILE_PATH + properties.getProperty("GEN_LOG_PATH");
			DOCUMENT_LOCATION = EXE_FILE_PATH + properties.getProperty("DOCUMENT_LOCATION");
			SPACE = properties.getProperty("SPACE");
			BACK_FOLDER = EXE_FILE_PATH + properties.getProperty("BACK_FOLDER");
			CREATE_NUM = Integer.parseInt(properties.getProperty("CREATE_NUM"));
			CATEGORY = properties.getProperty("CATEGORY");
			WAITTIME = Integer.parseInt(properties.getProperty("WAITTIME"));
			if (StringUtils.isNotEmpty(properties.getProperty("IGNORE_TEXT"))) {
				IGNORE_TEXT = Arrays.asList(properties.getProperty("IGNORE_TEXT").split(","));
			}
			CLASSIFICATION_FOLDER = EXE_FILE_PATH + properties.getProperty("CLASSIFICATION_FOLDER");
			PRIORITY_CHOOSE = Boolean.parseBoolean(properties.getProperty("PRIORITY_CHOOSE"));
			DOWNLOAD_PATH = (properties.getProperty("DOWNLOAD_PATH").equals("NO")) ? System.getProperty("user.home") + "\\Downloads\\" : properties.getProperty("DOWNLOAD_PATH");
			PDF_FILEPATH = EXE_FILE_PATH + properties.getProperty("PDF_FILEPATH");
		} catch (IOException e) {
			Log.printException("读取核心配置文件[config.properties]异常", e);
		}
	}
}
