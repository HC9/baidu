package com.laoxue.config;

import java.util.*;
/**
 *  常量接口
 *  @author 老薛 vx:kengwanglaoxue
 */
public interface CommonValue {

    String GENERATION_HREF = "https://xiezuocat.com/#/";

    String OK_TITLE_FILE = "\\OK\\";
    String POOR_TITLE_FILE = "\\POOR\\";

    Map<String,String> CREATE_FOLDER = new HashMap<String,String>(){{
        put("推荐","01tuijian");put("学前教育","02xueqianjiaoyu");put("基础教育","03jichujiaoyu");
        put("高校与高等教育","04gaoxiaoyugaodeng");put("语言/资格考试","05yuyan");put("法律","06falv");
        put("建筑","07jianzhu");put("互联网","08hulianwang");put("行业资料","09hangyeziliao");
        put("政务民生","10zwms");put("商品说明书","11shangping");put("实用模板","12shiyong");
        put("生活娱乐","13shenghuo");
    }};

    List<String> FILTER_KEYWORD = new ArrayList<>(Arrays.asList("什么","意思","怎么","组词","说说","句子","诗",
            "哪","最","如何","做法","会","吗","读音","是","范文","新闻稿","总结","使用","说明","手册","招标",
            "模版","方案","语录")) ;

    String SEGMENTATION = "@";
    String COMMA = ",";
    String DOT = ".";
}
