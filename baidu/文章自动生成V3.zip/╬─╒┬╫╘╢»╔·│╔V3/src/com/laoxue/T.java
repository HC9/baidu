package com.laoxue;

/**
 *
 */
public class T {
    public static void main(String[] args) {

        System.out.println("abcd".replace("@",","));

    }
}
