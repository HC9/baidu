package com.laoxue.action;

import com.laoxue.util.Log;

import static com.laoxue.generation.GenerationController.generationArticle;
import static com.laoxue.util.FileUtil.fixUpTitle;

/**
 *  项目启动类
 *  @author 老薛 vx:kengwanglaoxue
 */
public class Action {
    public static void main(String[] args) {
        Log.printSuccess(" GO GO GO GO GO GO GO GO GO GO GO GO GO GO ","##############");
        Log.printSuccess("开始运行了，先烧一柱香","保佑一路成功");
        Log.printSuccess("开始运行了，再烧一柱香","保佑全程无BUG");
        Log.printSuccess("开始运行了，最后一柱香","上传全通过");
        Log.printSuccess(" GO GO GO GO GO GO GO GO GO GO GO GO GO GO ","##############\n\n");
        // 整理文档信息
        fixUpTitle();
        // 生成文章
        generationArticle();

        Log.printSuccess("结束了","结束了\n");

        Log.printSuccess(" 运行结束 ","author:vx:kengwanglaoxue");
    }
}
