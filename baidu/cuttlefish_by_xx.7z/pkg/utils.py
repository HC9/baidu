# coding: utf-8

import json
import csv
from typing import List


def load_json_from_file(path: str) -> dict:
    with open(path, 'r') as f:
        return json.loads(f.read())


def dump_to_json(object: any, output_path: str):
    with open(output_path, 'w') as f:
        f.write(json.dumps(object, ensure_ascii=False, indent=4))


def dump_to_csv(data: List[dict], keys: List[str], output_path: str):
    simplify_data = []
    for item in data:
        simplify_data.append({k: item.get(k, '') for k in keys})

    with open(output_path, 'w') as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(simplify_data)
    

# tests

if __name__ == '__main__':
    data = [
        {
            'name': 'Peter',
            'age': 10,
            'gender': 'male'
        },
        {
            'name': 'Emma',
            'age': 16,
            'gender': 'female'
        }
    ]
    dump_to_csv(data, ['name', 'age', 'gender'], 'utils_dump_test.csv')
    