# coding: utf-8

import csv
import time
import requests
import os
from docx import Document
from loguru import logger
from pkg import parse_curl, utils
from typing import List
from pychatgpt import Chat, Options



class Client(object):
    def __init__(self) -> None:
        pass


def raise_on_unexpected_resp(resp):
    if resp.status_code != 200:
        status_code, content = resp.status_code, resp.content
        err_msg = f'unexpected response, status_code={status_code}, content={content}'
        logger.error(err_msg)
        raise Exception(err_msg)


def raise_on_unexpected_errcode(resp):
    err_code = resp['errCode']
    if err_code == 0:
        return

    if err_code == 4004:
        err_msg = f'unexpected err response, err_msg=需要在网页上完成认证, reps={resp}'
        logger.error(err_msg)
        raise Exception(err_msg)


    resp_err_msg = resp['errMsg']
    err_msg = f'unexpected err response, err_msg={resp_err_msg}, reps={resp}'
    logger.error(err_msg)
    raise Exception(err_msg)



def generate_article_by_title(title: str) -> dict:
    settings = utils.load_json_from_file('conf/settings.json')

    options = Options()
    options.proxies = settings['chatgpt']['proxies']
    email = settings['chatgpt']['email']
    password = settings['chatgpt']['password']
    
    chat = Chat(email=email, password=password, options=options) 

    logger.info(f'ask chatGPT write content about `{title}`')
    content = chat.ask(f"以《{title}》为标题，写一篇800字文章")
    # TODO: error check
    contents = [content]
    total_words = len(content)
    is_end_with_period = False
    
    while total_words < 500 and not is_end_with_period:
        logger.info(f'ask chatGPT keep write content about `{title}`, total_words={total_words}, is_end_with_period={is_end_with_period}')
        content = chat.ask("继续")
        # TODO: error check
        contents.append(content)
        total_words += len(content)
        is_end_with_period = content.endswith('。')

    article = ''.join(contents)
    return article
    

def load_tasks() -> List[dict]:
    with open('output/tasks.csv', 'r') as f:
        reader = csv.DictReader(f)
        return [item for item in reader]


def generate_article_docx(article_data: dict, output_path: str):
    document = Document()
    document.add_heading(article_data['title'], 0)

    # 增加介绍
    # document.add_paragraph(article_data['intro'])

    # 写入正文
    document.add_paragraph(article_data['content'])
    # contents = article_data['contents']
    # for content in contents:
    #     document.add_heading(content['title'], level=2)
    #     document.add_paragraph(content['intro'])

    document.save(output_path)

def main2():
    article = generate_article_by_title('关于二婚的看法')
    print(article)


def main():
    # 加载任务列表
    tasks = load_tasks()
    logger.info(f'{len(tasks)} tasks is loaded')

    # 遍历任务列表生成文章
    for task in tasks[:20]:
        title = task['title']

        if title.find('/') != -1:
            # 忽略标题有斜杠的的任务
            continue
    
        output_path = f'output/articles/{title}.docx'
        if os.path.exists(output_path):
            logger.info(f'`{output_path}` already exists')
            continue
        
        logger.info(f'generate article by title, title={title}')
        start_at = time.time()
        article_content = generate_article_by_title(title)
        article_data = {
            'title': title,
            'content': article_content,
        }
        elapsed = time.time() - start_at
        logger.info(f'generate article by title success, title={title}, cost={elapsed:.2f}s')

        logger.info(f'generate article docx by title, title={title}')
        generate_article_docx(article_data, output_path)

    # curl_data = parse_curl.parse_from_file('conf/xiezuocat_curl.txt')
    # headers = curl_data['headers']
    # title = '如何做饭好吃'
    # intro = generate_intro(headers, title)
    # outlines = generate_outlines(headers, title, intro)
    # article = generate_article(headers, title, intro, outlines)
    # utils.dump_to_json(article, f'{title}_article.json')


if __name__ == '__main__':
    main()
